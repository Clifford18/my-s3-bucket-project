my website-endpoint URL: http://my-1006-6227-9391-bucket.s3-website-us-east-1.amazonaws.com
CloudFront domain :   https://d2qbdkc59olwc9.cloudfront.net/
Github Repository: https://github.com/Clifford18/my-s3-bucket-project